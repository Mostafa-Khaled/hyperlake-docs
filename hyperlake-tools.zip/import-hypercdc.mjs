import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { load } from 'cheerio';

const root        = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const configFile  = process.argv[2] || 'hypercdc.config.json';
const configPath  = path.join(root, 'dist', configFile);
const config      = JSON.parse(await fs.readFile(configPath, 'utf8'));
const outputDir   = path.join(root, config.outputDir);
const customVisDir = path.join(root, 'dist', 'custom-visuals');
const imagesOutDir = path.join(outputDir, 'images');
const sourceRoot  = new URL(config.sourceRoot);
const seen        = new Set();
const pages       = [];
const allVisuals  = [];
const searchIndex = [];
const downloadedAssets = new Map();
const sleep       = (ms) => new Promise((r) => setTimeout(r, ms));

await fs.mkdir(customVisDir, { recursive: true });
await fs.mkdir(imagesOutDir, { recursive: true });

function normalizeUrl(value, from) {
  try {
    const url = new URL(value, from);
    url.hash = '';
    if (url.protocol !== 'https:' || url.hostname !== sourceRoot.hostname) return null;
    if (!url.pathname.startsWith(sourceRoot.pathname)) return null;
    const p = url.pathname;
    const isHtml = /\.(html?|xhtml)$/.test(p);
    const isDir  = p.endsWith('/') || (!p.includes('.') && p !== sourceRoot.pathname);
    if (!isHtml && !isDir) return null;
    if (isDir && !isHtml) url.pathname = p.replace(/\/?$/, '/') + 'index.html';
    return url.href;
  } catch { return null; }
}

function rebrandSegment(seg) {
  let result = seg;
  for (const [from, to] of Object.entries(config.replacements || {})) {
    result = result.replaceAll(from, to);
  }
  return result;
}

function outputPath(url) {
  const rel  = new URL(url).pathname.slice(sourceRoot.pathname.length).replace(/^\/+/, '');
  const html = rel.endsWith('.html') ? rel : `${rel.replace(/\/$/, '') || 'index'}.html`;
  return path.join(outputDir, html.split('/').map(rebrandSegment).join('/'));
}

function escapeHtml(v) {
  return String(v || '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
}

function applyRebranding(text) {
  if (!text) return '';
  return Object.entries(config.replacements).reduce((acc, [from, to]) => acc.replaceAll(from, to), text);
}

const FETCH_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'
};

async function downloadAsset(url, desiredName) {
  if (downloadedAssets.has(url)) return downloadedAssets.get(url);
  try {
    const res = await fetch(url, { headers: FETCH_HEADERS });
    if (!res.ok) {
      console.warn(`Failed to download ${url}: ${res.status}`);
      return null;
    }
    const buffer = Buffer.from(await res.arrayBuffer());
    const destPath = path.join(imagesOutDir, desiredName);
    await fs.writeFile(destPath, buffer);
    downloadedAssets.set(url, desiredName);
    return desiredName;
  } catch (err) {
    console.warn(`Error downloading ${url}:`, err.message);
    return null;
  }
}

async function processVisuals($, $content, sourceUrl, pageRelPath, pageTitle) {
  const pageSlug = pageRelPath.replace(/\\/g, '/').replace(/\.html$/, '').replace(/[^a-zA-Z0-9_-]/g, '-');
  let visualIndex = 0;

  const targets = $content.find('.imageblock, img, svg, picture, video, iframe, object');

  for (const el of targets.toArray()) {
    if (el.tagName === 'img' && $(el).closest('.imageblock').length) continue;

    visualIndex++;
    const visualId = `fig-${pageSlug}-${visualIndex}`;
    const isImageBlock = $(el).hasClass('imageblock');
    const imgEl = el.tagName === 'img' ? $(el) : $(el).find('img').first();
    const isIframe = el.tagName === 'iframe';
    const rawSrc = imgEl.attr('src') || $(el).attr('src') || '';
    const captionRaw = $(el).find('.title').text() || $(el).attr('title') || imgEl.attr('alt') || 'Architecture / Workflow Diagram';
    const caption = applyRebranding(captionRaw.trim());

    let originalAbsoluteUrl = '';
    if (rawSrc) {
      try {
        originalAbsoluteUrl = new URL(rawSrc, sourceUrl).href;
      } catch {
        originalAbsoluteUrl = rawSrc;
      }
    }

    let localFile = null;
    const possibleExts = ['.png', '.svg', '.jpg', '.jpeg', '.webp', '.gif'];
    for (const ext of possibleExts) {
      const customPath = path.join(customVisDir, `${visualId}${ext}`);
      try {
        await fs.access(customPath);
        const destFile = `${visualId}${ext}`;
        await fs.copyFile(customPath, path.join(imagesOutDir, destFile));
        localFile = destFile;
        break;
      } catch {}
    }

    const relToDocsRoot = path.relative(path.dirname(path.join(outputDir, pageRelPath)), outputDir).replaceAll('\\', '/') || '.';
    const catalogHref = `${relToDocsRoot}/visuals-catalog.html#${visualId}`;

    allVisuals.push({
      id: visualId,
      pageTitle,
      pageRelPath: pageRelPath.replace(/\\/g, '/'),
      sourceUrl,
      originalSrc: originalAbsoluteUrl || '(Inline / Embedded)',
      caption,
      tag: el.tagName,
      localFile: localFile ? `images/${localFile}` : null,
      isIframe
    });

    if (localFile) {
      const imgSrc = `${relToDocsRoot}/images/${localFile}`;
      const customHtml = `<figure class="visual-figure" id="${visualId}">
        <img src="${imgSrc}" alt="${escapeHtml(caption)}" class="visual-custom">
        <figcaption class="visual-caption">${escapeHtml(applyRebranding(caption))}</figcaption>
      </figure>`;
      $(el).replaceWith(customHtml);
    } else {
      const placeholderHtml = `<figure class="visual-placeholder" id="${visualId}">
        <div class="visual-placeholder__header">
          <span class="visual-placeholder__badge">Visual Asset <code>#${visualId}</code></span>
          <span class="status-pill pending">Pending HyperLake Rebrand</span>
        </div>
        <div class="visual-placeholder__title">${escapeHtml(applyRebranding(caption))}</div>
        <div class="visual-placeholder__meta">
          ${originalAbsoluteUrl ? `<span>Original: <a href="${originalAbsoluteUrl}" target="_blank" rel="noopener" class="external-visual-link">View source asset &nearr;</a></span> <span>&bull;</span>` : ''}
          <a href="${catalogHref}">Review in Visuals Catalog &rarr;</a>
        </div>
      </figure>`;
      $(el).replaceWith(placeholderHtml);
    }
  }
}

function cleanAdmonitions($, $target) {
  $target.find('.admonitionblock').each((_, el) => {
    const $block = $(el);
    let type = 'note';
    if ($block.hasClass('tip')) type = 'tip';
    else if ($block.hasClass('warning')) type = 'warning';
    else if ($block.hasClass('important')) type = 'important';
    else if ($block.hasClass('caution')) type = 'caution';

    const titleText = type.toUpperCase();
    const contentHtml = $block.find('td.content').html() || $block.html();

    $block.empty().html(`
      <div class="admonition-header">
        <span class="admonition-label">${titleText}</span>
      </div>
      <div class="admonition-body">
        ${contentHtml}
      </div>
    `);
  });
}

function enhanceTables($, $target) {
  $target.find('table').each((_, table) => {
    if ($(table).closest('.admonitionblock').length) return;
    if ($(table).parent().hasClass('table-container')) return;
    $(table).find('colgroup col').removeAttr('style');
    $(table).wrap('<div class="table-container"></div>');
  });
}

const killDomains = (config.killExternalDomains || []).map(
  d => new RegExp('https?:\\/\\/[^\\s"\']*('+d.replace(/\./g, '\\.')+')[^\\s"\']* ', 'g')
);

function rewriteLinksAndIds($, $target, sourceUrl, pageFile) {
  $target.find('[id]').each((_, el) => {
    const id = $(el).attr('id');
    if (id) $(el).attr('id', applyRebranding(id));
  });

  $target.find('a[href]').each((_, el) => {
    if ($(el).hasClass('external-visual-link')) return;

    let href = $(el).attr('href') || '';
    if (href === '#') return;

    if (href.startsWith('#')) {
      $(el).attr('href', applyRebranding(href));
      return;
    }

    if (href.startsWith('mailto:') || href.startsWith('javascript:')) return;

    let targetAbs;
    try {
      targetAbs = new URL(href, sourceUrl).href;
    } catch {
      return;
    }

    const norm = normalizeUrl(targetAbs, sourceUrl);
    if (norm) {
      const targetPageFile = outputPath(norm);
      const rel = path.relative(path.dirname(pageFile), targetPageFile).replaceAll('\\', '/');
      const hash = new URL(targetAbs, sourceUrl).hash;
      $(el).attr('href', (rel || './') + (hash ? applyRebranding(hash) : ''));
    } else {
      if (killDomains.some(re => { re.lastIndex = 0; return re.test(href); })) {
        $(el).attr('href', '#');
      }
    }
  });
}

function applyTextRebranding($, $target) {
  function rebrandNode(node) {
    if (!node) return;
    if (node.type === 'text') {
      node.data = applyRebranding(node.data);
    } else if (node.children) {
      for (const child of node.children) rebrandNode(child);
    }
  }
  const rootNode = typeof $target.root === 'function' ? $target.root()[0] : $target[0];
  rebrandNode(rootNode);
}

function sanitizeDOM($, sourceUrl, pageFile, pageTitle) {
  const removeSelectors = (config.selectors?.remove || 'script, style, noscript, header, footer, nav, aside, .toolbar, .page-versions-container').split(',').map(s => s.trim());
  for (const sel of removeSelectors) $(sel).remove();

  cleanAdmonitions($);
  enhanceTables($);
  rewriteLinksAndIds($, sourceUrl, pageFile);
  applyTextRebranding($);
}

function searchBar() {
  return [
    '  <div class="topbar__center">',
    '    <div class="search-wrap">',
    '      <svg class="search-icon" viewBox="0 0 20 20" fill="none" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5" stroke="currentColor" stroke-width="1.6"/><path d="m13 13 3.5 3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    '      <input type="search" id="docs-search-input" class="search-input" placeholder="Search docs\u2026" autocomplete="off" spellcheck="false">',
    '      <kbd class="search-kbd">/</kbd>',
    '      <div id="docs-search-results" class="search-results" role="listbox"></div>',
    '    </div>',
    '  </div>'
  ].join('\n');
}

function pageShell(title, content, pageFile) {
  const screenCss  = path.relative(path.dirname(pageFile), path.join(outputDir, 'hypercdc-screen.css')).replaceAll('\\', '/');
  const printCss   = path.relative(path.dirname(pageFile), path.join(outputDir, 'hypercdc-print.css')).replaceAll('\\', '/');
  const docsIndex  = path.relative(path.dirname(pageFile), path.join(outputDir, 'index.html')).replaceAll('\\', '/');
  const catalogHref = path.relative(path.dirname(pageFile), path.join(outputDir, 'visuals-catalog.html')).replaceAll('\\', '/');
  const portalHome = path.relative(path.dirname(pageFile), path.join(root, 'index.html')).replaceAll('\\', '/');
  const searchJs   = path.relative(path.dirname(pageFile), path.join(outputDir, 'search.js')).replaceAll('\\', '/');
  const docsRoot   = path.relative(path.dirname(pageFile), outputDir).replaceAll('\\', '/').replace(/^$/, '.')  + '/';

  return [
    '<!doctype html>',
    '<html lang="en">',
    '<head>',
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width,initial-scale=1">',
    `<title>${escapeHtml(title)} — ${config.brand}</title>`,
    `<link rel="stylesheet" href="${screenCss}">`,
    `<link rel="stylesheet" media="print" href="${printCss}">`,
    '</head>',
    `<body data-docs-root="${docsRoot}">`,
    '<header class="topbar">',
    '  <div class="topbar__left">',
    `    <a class="topbar__brand" href="${docsIndex}">${config.brand}</a>`,
    `    <span class="topbar__version">${config.version}</span>`,
    '  </div>',
    searchBar(),
    '  <div class="topbar__right">',
    `    <a class="topbar__nav-link" href="${docsIndex}">Docs Index</a>`,
    `    <a class="topbar__nav-link" href="${catalogHref}">Visuals Catalog</a>`,
    `    <a class="topbar__nav-link" href="${portalHome}">&larr; HyperLake Portal</a>`,
    '  </div>',
    '</header>',
    '<div class="page-content">',
    content,
    '</div>',
    `<script src="${searchJs}"></script>`,
    '</body>',
    '</html>'
  ].join('\n');
}

async function importPage(url) {
  if (seen.has(url)) return;
  seen.add(url);

  const res = await fetch(url, { headers: FETCH_HEADERS });
  if (!res.ok) {
    console.error(`Failed ${url}: ${res.status}`);
    return;
  }

  const html = await res.text();
  const $ = load(html);

  const rawTitle = $('title').text().replace(/\s*::\s*Debezium Documentation.*$/i, '').trim() || 'HyperCDC Documentation';
  const pageTitle = applyRebranding(rawTitle);

  const discovered = [];
  $('a[href]').each((_, el) => {
    const raw = $(el).attr('href');
    if (!raw) return;
    const abs = normalizeUrl(raw, url);
    if (abs) discovered.push(abs);
  });

  const pageFile = outputPath(url);
  const relPath  = path.relative(outputDir, pageFile);

  const removeSelectors = (config.selectors?.remove || 'script, style, noscript, header, footer, nav, aside, .toolbar, .page-versions-container').split(',').map(s => s.trim());
  for (const sel of removeSelectors) $(sel).remove();

  let $content = $('article.doc');
  if (!$content.length) $content = $('main');
  if (!$content.length) $content = $('.main');
  if (!$content.length) $content = $('body');

  await processVisuals($, $content, url, relPath, pageTitle);

  cleanAdmonitions($, $content);
  enhanceTables($, $content);
  rewriteLinksAndIds($, $content, url, pageFile);
  applyTextRebranding($, $content);

  const mainHtml  = $content.html() || '';
  const plainText = $content.text().replace(/\s+/g, ' ').trim();
  searchIndex.push({
    title: pageTitle,
    url:   relPath.replace(/\\/g, '/'),
    text:  plainText
  });

  await fs.mkdir(path.dirname(pageFile), { recursive: true });
  await fs.writeFile(pageFile, pageShell(pageTitle, mainHtml, pageFile), 'utf8');

  pages.push({ url, title: pageTitle, file: pageFile, relPath });
  console.log(`Imported [${pages.length}]: ${pageTitle} (${relPath})`);

  for (const next of discovered) {
    if (!seen.has(next)) {
      await sleep(15);
      await importPage(next);
    }
  }
}

async function generateIndex() {
  console.log('Generating Table of Contents...');

  const childOf = config.childPages || {};
  const childSet = new Set(Object.keys(childOf));

  const seenPaths = new Set();
  const uniquePages = [];
  for (const p of pages) {
    const key = p.relPath.replace(/\\/g, '/');
    if (!seenPaths.has(key)) { seenPaths.add(key); uniquePages.push(p); }
  }

  const groups = new Map();
  for (const p of uniquePages) {
    const rel = p.relPath.replace(/\\/g, '/');
    if (childSet.has(rel)) continue;
    const parts = rel.split('/');
    const section = parts.length > 1 ? parts[0] : 'General';
    if (!groups.has(section)) groups.set(section, []);
    groups.get(section).push(p);
  }

  const childrenByParent = new Map();
  for (const [child, parent] of Object.entries(childOf)) {
    if (!childrenByParent.has(parent)) childrenByParent.set(parent, []);
    const childPage = uniquePages.find(p => p.relPath.replace(/\\/g, '/') === child);
    if (childPage) childrenByParent.get(parent).push(childPage);
  }

  let html = `<div class="index-hero">
    <h1>HyperCDC Documentation</h1>
    <p>Reference documentation and operational guide for HyperCDC — unified change data capture across operational databases.</p>
  </div>
  <div class="index-grid">`;

  for (const [section, sectionPages] of groups.entries()) {
    const sectionTitle = section.charAt(0).toUpperCase() + section.slice(1).replace(/-/g, ' ');
    html += `\n  <div class="index-card">\n    <h2>${escapeHtml(sectionTitle)}</h2>\n    <ul>`;
    for (const sp of sectionPages) {
      const rel = sp.relPath.replace(/\\/g, '/');
      html += `\n      <li><a href="${rel}">${escapeHtml(sp.title)}</a>`;
      const children = childrenByParent.get(rel);
      if (children && children.length) {
        html += `\n        <ul class="index-sublist">`;
        for (const ch of children) {
          html += `\n          <li><a href="${ch.relPath.replace(/\\/g, '/')}">${escapeHtml(ch.title)}</a></li>`;
        }
        html += `\n        </ul>`;
      }
      html += `</li>`;
    }
    html += `\n    </ul>\n  </div>`;
  }
  html += `\n</div>`;

  const indexShell = [
    '<!doctype html>',
    '<html lang="en">',
    '<head>',
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width,initial-scale=1">',
    `<title>HyperCDC Documentation Index</title>`,
    '<link rel="stylesheet" href="hypercdc-screen.css">',
    '<link rel="stylesheet" media="print" href="hypercdc-print.css">',
    '</head>',
    '<body data-docs-root="./">',
    '<header class="topbar">',
    '  <div class="topbar__left">',
    `    <a class="topbar__brand" href="index.html">${config.brand}</a>`,
    `    <span class="topbar__version">${config.version}</span>`,
    '  </div>',
    searchBar(),
    '  <div class="topbar__right">',
    `    <a class="topbar__nav-link" href="visuals-catalog.html">Visuals Catalog (${allVisuals.length})</a>`,
    `    <a class="topbar__nav-link" href="../index.html">&larr; HyperLake Portal</a>`,
    '  </div>',
    '</header>',
    '<div class="page-content index-page">',
    html,
    '</div>',
    '<script src="search.js"></script>',
    '</body>',
    '</html>'
  ].join('\n');

  await fs.writeFile(path.join(outputDir, 'index.html'), indexShell, 'utf8');
}

async function generateVisualsCatalog() {
  console.log('Generating Visuals Review Catalog...');

  const manifestPath = path.join(root, 'dist', 'visuals-manifest.json');
  await fs.writeFile(manifestPath, JSON.stringify({ total: allVisuals.length, visuals: allVisuals }, null, 2), 'utf8');

  let catalogHtml = `<div class="catalog-header">
    <h1>Visual Assets &amp; Architecture Diagrams</h1>
    <p>Indexed ${allVisuals.length} visual assets across HyperCDC documentation. Images are downloaded and served locally.</p>
  </div>
  <div class="visuals-grid">`;

  for (const v of allVisuals) {
    const pageHref = v.pageRelPath + '#' + v.id;
    const preview = v.localFile
      ? `<img src="${v.localFile}" alt="${escapeHtml(v.caption)}" class="catalog-thumb">`
      : `<div class="catalog-thumb-placeholder">Video / Media Embed</div>`;

    catalogHtml += `
    <div class="catalog-card" id="${v.id}">
      <div class="catalog-card__preview">
        ${preview}
      </div>
      <div class="catalog-card__body">
        <div class="catalog-card__id">${v.id}</div>
        <h3 class="catalog-card__caption">${escapeHtml(v.caption)}</h3>
        <p class="catalog-card__meta">
          <strong>Page:</strong> <a href="${pageHref}">${escapeHtml(v.pageTitle)}</a><br>
          <strong>File:</strong> <code>${v.localFile || v.originalSrc}</code>
        </p>
      </div>
    </div>`;
  }

  catalogHtml += `\n</div>`;

  const catalogShell = [
    '<!doctype html>',
    '<html lang="en">',
    '<head>',
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width,initial-scale=1">',
    `<title>Visuals Catalog — HyperCDC</title>`,
    '<link rel="stylesheet" href="hypercdc-screen.css">',
    '<link rel="stylesheet" media="print" href="hypercdc-print.css">',
    '</head>',
    '<body data-docs-root="./">',
    '<header class="topbar">',
    '  <div class="topbar__left">',
    `    <a class="topbar__brand" href="index.html">${config.brand}</a>`,
    `    <span class="topbar__version">${config.version}</span>`,
    '  </div>',
    searchBar(),
    '  <div class="topbar__right">',
    `    <a class="topbar__nav-link" href="index.html">Docs Index</a>`,
    `    <a class="topbar__nav-link" href="../index.html">&larr; HyperLake Portal</a>`,
    '  </div>',
    '</header>',
    '<div class="page-content catalog-page">',
    catalogHtml,
    '</div>',
    '<script src="search.js"></script>',
    '</body>',
    '</html>'
  ].join('\n');

  await fs.writeFile(path.join(outputDir, 'visuals-catalog.html'), catalogShell, 'utf8');
  console.log(`Generated visuals catalog with ${allVisuals.length} assets.`);
}

async function copyAssets() {
  const rootScreenCss = path.join(root, 'hypercdc-screen.css');
  const rootPrintCss  = path.join(root, 'hypercdc-print.css');
  try {
    await fs.copyFile(rootScreenCss, path.join(outputDir, 'hypercdc-screen.css'));
    await fs.copyFile(rootPrintCss, path.join(outputDir, 'hypercdc-print.css'));
  } catch (e) {
    console.warn('CSS copy warning:', e.message);
  }
}

async function generateSearchIndex() {
  const unique = [];
  const seen2 = new Set();
  for (const entry of searchIndex) {
    if (!seen2.has(entry.url)) { seen2.add(entry.url); unique.push(entry); }
  }
  await fs.writeFile(path.join(outputDir, 'search-index.json'), JSON.stringify(unique), 'utf8');
  console.log(`Generated search index with ${unique.length} pages.`);
}

async function main() {
  console.log(`Starting crawl from ${config.sourceRoot}...`);
  await importPage(config.sourceRoot);
  await copyAssets();
  await fs.copyFile(path.join(root, 'dist', 'search.js'), path.join(outputDir, 'search.js'));
  await generateSearchIndex();
  await generateIndex();
  await generateVisualsCatalog();
  console.log(`\n✓ Successfully generated ${pages.length} documentation pages and downloaded ${downloadedAssets.size} visual assets into hypercdc-docs.`);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
